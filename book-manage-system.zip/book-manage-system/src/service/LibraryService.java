package service;

import dao.BookDAO;
import dao.BorrowRecordDAO;
import dao.UserDAO;
import model.Book;
import model.BorrowRecord;
import model.User;

import java.sql.SQLException;
import java.util.List;

public class LibraryService {

    private BookDAO bookDAO = new BookDAO();
    private UserDAO userDAO = new UserDAO();
    private BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();

    // 获取所有图书
    public List<Book> getAllBooks() {
        try {
            return bookDAO.getAllBooks();
        } catch (SQLException e) {
            System.err.println("获取图书时发生错误: " + e.getMessage());
            return null;  // 发生错误时返回null
        }
    }

    // 通过ID获取图书
    public Book getBookById(int bookId) {
        try {
            return bookDAO.getBookById(bookId);
        } catch (SQLException e) {
            System.err.println("通过ID获取图书时发生错误: " + e.getMessage());
            return null;  // 发生错误时返回null
        }
    }

    // 用户注册
    public boolean registerUser(String username, String password) {
        try {
            // 检查用户名是否已存在
            if (userDAO.getUserByUsername(username) != null) {
                System.err.println("用户名已存在");
                return false;  // 用户已存在
            }

            // 注册新用户
            User newUser = new User(username, password, "用户");  // 默认角色为USER
            return userDAO.createUser(newUser);
        } catch (SQLException e) {
            System.err.println("注册用户时发生错误: " + e.getMessage());
            return false;  // 注册失败
        }
    }

    // 用户登录
    public User loginUser(String username, String password) {
        try {
            User user = userDAO.getUserByUsername(username);
            if (user != null && user.getPassword().equals(password)) {
                return user;  // 登录成功，返回用户
            }
            return null;  // 登录失败，用户名或密码错误
        } catch (SQLException e) {
            System.err.println("登录时发生错误: " + e.getMessage());
            return null;  // 发生错误时返回null
        }
    }

    // 借阅图书
    public boolean borrowBook(int userId, int bookId) {
        try {
            Book book = bookDAO.getBookById(bookId);
            if (book != null && book.getQuantity() > 0) {
                // 创建借阅记录
                boolean success = borrowRecordDAO.createBorrowRecord(userId, bookId);
                if (success) {
                    // 更新图书库存
                    bookDAO.updateBookQuantity(bookId, book.getQuantity() - 1);
                    return true;
                }
            }
            return false;  // 借阅失败，库存不足或其他原因
        } catch (SQLException e) {
            System.err.println("借阅图书时发生错误: " + e.getMessage());
            return false;  // 发生错误时返回false
        }
    }

    // 管理员增加图书
    public boolean addBook(String title, String author, int quantity) {
        try {
            Book newBook = new Book(title, author, quantity);
            return bookDAO.addBook(newBook);
        } catch (SQLException e) {
            System.err.println("添加图书时发生错误: " + e.getMessage());
            return false;  // 发生错误时返回false
        }
    }

    // 管理员删除图书
    public boolean deleteBook(int bookId) {
        try {
            return bookDAO.deleteBook(bookId);
        } catch (SQLException e) {
            System.err.println("删除图书时发生错误: " + e.getMessage());
            return false;  // 发生错误时返回false
        }
    }

    // 管理员更新图书信息
    public boolean updateBook(int bookId, String title, String author, int quantity) {
        try {
            Book updatedBook = new Book(bookId, title, author, quantity);
            return bookDAO.updateBook(updatedBook);
        } catch (SQLException e) {
            System.err.println("更新图书信息时发生错误: " + e.getMessage());
            return false;  // 发生错误时返回false
        }
    }

    // 查看借阅记录
    public List<BorrowRecord> viewAllBorrowRecords() {
        try {
            return borrowRecordDAO.getAllBorrowRecords();
        } catch (SQLException e) {
            System.err.println("获取借阅记录时发生错误: " + e.getMessage());
            return null;  // 发生错误时返回null
        }
    }

    // 通过用户名获取用户信息
    public User getUserByUsername(String username) {
        try {
            return userDAO.getUserByUsername(username);
        } catch (SQLException e) {
            System.err.println("获取用户信息时发生错误: " + e.getMessage());
            return null;  // 发生错误时返回null
        }
    }
}
