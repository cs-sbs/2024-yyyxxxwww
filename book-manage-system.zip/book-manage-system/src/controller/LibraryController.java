package controller;

import model.Book;
import model.BorrowRecord;
import model.User;
import service.LibraryService;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class LibraryController {

    private LibraryService libraryService = new LibraryService();
    private Scanner scanner = new Scanner(System.in);
    private User currentUser = null;  // 当前登录用户

    // 显示所有图书信息
    public void displayAllBooks() {
        List<Book> books = libraryService.getAllBooks();
        System.out.println("\n图书馆中的图书：");
        System.out.println("| ID   | 书名                          | 作者               | 库存   |");
        for (Book book : books) {
            System.out.printf("| %-4d | %-30s | %-20s | %-8d |\n", book.getId(), book.getTitle(), book.getAuthor(), book.getQuantity());
        }
    }

    // 显示用户信息
    public void displayUserInfo(String username) {
        User user = libraryService.getUserByUsername(username);
        if (user != null) {
            System.out.println("\n用户信息：");
            System.out.println(user);
        } else {
            System.out.println("未找到该用户。");
        }
    }

    // 注册用户
    public void registerUser() {
        System.out.print("请输入用户名：");
        String username = scanner.nextLine();
        System.out.print("请输入密码：");
        String password = scanner.nextLine();

        boolean success = libraryService.registerUser(username, password);
        if (success) {
            System.out.println("注册成功！请登录。");
        } else {
            System.out.println("用户名已存在，请重新输入。");
        }
    }

    // 登录功能
    public boolean loginUser() {
        System.out.print("请输入用户名：");
        String username = scanner.nextLine();
        System.out.print("请输入密码：");
        String password = scanner.nextLine();

        currentUser = libraryService.loginUser(username, password);
        if (currentUser != null) {
            System.out.println("登录成功！欢迎 " + currentUser.getUsername());

            // 根据角色判断显示不同菜单
            if ("管理员".equals(currentUser.getRole())) {
                showAdminMenu(); // 显示管理员菜单
            } else {
                showUserMenu(); // 显示普通用户菜单
            }
            return true;
        } else {
            System.out.println("用户名或密码错误。");
            return false;
        }
    }

    // 借阅图书功能
    public void borrowBook() {
        if (currentUser == null) {
            System.out.println("请先登录！");
            return;
        }

        System.out.print("请输入借阅的图书ID：");
        int bookId = scanner.nextInt();
        scanner.nextLine();  // 清除换行符

        Book book = libraryService.getBookById(bookId);
        if (book != null && book.getQuantity() > 0) {
            boolean success = libraryService.borrowBook(currentUser.getId(), bookId);
            if (success) {
                System.out.println("成功借阅图书《" + book.getTitle() + "》！");
            } else {
                System.out.println("借阅失败，请稍后再试。");
            }
        } else {
            System.out.println("图书不存在或库存不足。");
        }
    }
    // 管理员功能菜单
    public void showAdminMenu() {
        while (true) {
            System.out.println("\n管理员功能菜单：");
            System.out.println("1. 增加图书");
            System.out.println("2. 删除图书");
            System.out.println("3. 更新图书信息");
            System.out.println("4. 查看借阅记录");
            System.out.println("5. 返回");

            int choice = scanner.nextInt();
            scanner.nextLine();  // 清除换行符

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    deleteBook();
                    break;
                case 3:
                    updateBook();
                    break;
                case 4:
                    viewBorrowRecords();
                    break;
                case 5:
                    System.out.println("返回用户菜单");
                    return;
                default:
                    System.out.println("无效的选项，请重新选择。");
            }
        }
    }

    // 添加图书
    private void addBook() {
        System.out.print("请输入图书标题：");
        String title = scanner.nextLine();
        System.out.print("请输入图书作者：");
        String author = scanner.nextLine();
        System.out.print("请输入图书库存：");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        boolean success = libraryService.addBook(title, author, quantity);
        if (success) {
            System.out.println("图书添加成功！");
        } else {
            System.out.println("图书添加失败，请稍后再试。");
        }
    }

    // 删除图书
    private void deleteBook() {
        System.out.print("请输入要删除的图书ID：");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        boolean success = libraryService.deleteBook(bookId);
        if (success) {
            System.out.println("图书删除成功！");
        } else {
            System.out.println("图书删除失败，请稍后再试。");
        }
    }

    // 更新图书信息
    private void updateBook() {
        System.out.print("请输入要更新的图书ID：");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("请输入新的图书标题：");
        String title = scanner.nextLine();
        System.out.print("请输入新的图书作者：");
        String author = scanner.nextLine();
        System.out.print("请输入新的库存数量：");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        boolean success = libraryService.updateBook(bookId, title, author, quantity);
        if (success) {
            System.out.println("图书信息更新成功！");
        } else {
            System.out.println("图书信息更新失败，请稍后再试。");
        }
    }

    // 查看借阅记录
    private void viewBorrowRecords() {
        List<BorrowRecord> records = libraryService.viewAllBorrowRecords();
        System.out.println("借阅记录：");
        for (BorrowRecord record : records) {
            System.out.println(record);
        }
    }

    // 显示主菜单并处理用户输入
    public void showMainMenu() {
        while (true) {
            System.out.println("\n欢迎进入图书馆系统");
            System.out.println("1. 登录");
            System.out.println("2. 注册");
            System.out.println("3. 退出");

            int choice = scanner.nextInt();
            scanner.nextLine();  // 消耗掉换行符

            switch (choice) {
                case 1:
                    if (loginUser()) {
                        showUserMenu();  // 登录成功后显示用户菜单
                    }
                    break;
                case 2:
                    registerUser();
                    break;
                case 3:
                    System.out.println("感谢使用，退出系统！");
                    return;
                default:
                    System.out.println("无效的选项，请重新选择。");
            }
        }
    }

    // 显示用户功能菜单
    public void showUserMenu() {
        while (true) {
            System.out.println("\n欢迎 " + currentUser.getUsername() + "！请选择操作：");
            System.out.println("1. 查看所有图书");
            System.out.println("2. 借阅图书");
            System.out.println("3. 查看个人信息");
            System.out.println("4. 退出");

            int choice = scanner.nextInt();
            scanner.nextLine();  // 清除换行符

            switch (choice) {
                case 1:
                    displayAllBooks();
                    break;
                case 2:
                    borrowBook();
                    break;
                case 3:
                    displayUserInfo(currentUser.getUsername());
                    break;
                case 4:
                    System.out.println("退出登录，谢谢使用！");
                    return;
                default:
                    System.out.println("无效的选项，请重新选择。");
            }
        }
    }

}
