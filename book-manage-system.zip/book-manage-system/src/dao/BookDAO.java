package dao;

import model.Book;
import model.BorrowRecord;
import utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    // 获取所有图书
    public List<Book> getAllBooks() throws SQLException {
        String query = "SELECT * FROM books";
        try (Connection conn = DBUtils.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            List<Book> books = new ArrayList<>();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");
                books.add(new Book(id, title, author, quantity));
            }
            return books;
        }
    }

    // 根据图书ID获取图书信息
    public Book getBookById(int bookId) throws SQLException {
        String query = "SELECT * FROM books WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String title = rs.getString("title");
                    String author = rs.getString("author");
                    int quantity = rs.getInt("quantity");
                    return new Book(bookId, title, author, quantity);
                }
            }
        }
        return null;
    }

    // 更新图书库存
    public boolean updateBookQuantity(int bookId, int newQuantity) throws SQLException {
        String query = "UPDATE books SET quantity = ? WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, newQuantity);
            stmt.setInt(2, bookId);
            return stmt.executeUpdate() > 0;
        }
    }

    // 添加图书
    public boolean addBook(Book book) throws SQLException {
        String query = "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setInt(3, book.getQuantity());
            return stmt.executeUpdate() > 0;
        }
    }

    // 删除图书
    public boolean deleteBook(int bookId) throws SQLException {
        String query = "DELETE FROM books WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            return stmt.executeUpdate() > 0;
        }
    }

    // 更新图书信息
    public boolean updateBook(Book book) throws SQLException {
        String query = "UPDATE books SET title = ?, author = ?, quantity = ? WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setInt(3, book.getQuantity());
            stmt.setInt(4, book.getId());
            return stmt.executeUpdate() > 0;
        }
    }
}
